// Henry Nguyen
// 111484010
// CSE 214 R06

package cse214hw1;

public class ArrayQueue<T> implements Queue {
    Object[] array;
    int counter;

    public ArrayQueue() {
        array = new Object[10];
        counter = 0;
    }

    @Override
    public void add(Object o){
        this.array[counter] = o;
        counter++;
    }

    @Override
    public Object remove(){
        if (array[0] == null)
            throw new java.util.NoSuchElementException("Error: Queue is Empty");
        else {
            Object temp = array[0];
            int i;
            for (i = 0; i < array.length - 1; i++)
                array[i] = array[i + 1];
            array[i] = null;
            counter--;
            return temp;
        }
    }

    @Override
    public Object peek() {
        if (array[0] == null)
            throw new java.util.NoSuchElementException("Error: Queue is Empty");
        else
         return array[0];
    }
}
