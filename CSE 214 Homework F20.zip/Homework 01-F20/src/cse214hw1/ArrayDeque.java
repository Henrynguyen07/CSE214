// Henry Nguyen
// 111484010
// CSE 214 R06

package cse214hw1;

import java.util.Arrays;

public class ArrayDeque<T> implements Deque{
    Object[] array;
    int front;
    int rear;

    public ArrayDeque() {
        array = new Object[10];
        front = -1;
        rear = 0;
    }

    public ArrayDeque(int size) {
        array = new Object[size];
        front = -1;
        rear = 0;
    }

    @Override
    public void addFirst(Object o) {
        if (isFull()) {
            System.out.println("Queue is Full");
            return;
        }
        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else if (front == 0)
            front = array.length - 1;
        else
            front--;
        array[front] = o;
    }

    @Override
    public void addLast(Object o)  {
        if (isFull()) {
            System.out.println("Queue is Full");
            return;
        }
        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else if (rear == array.length - 1)
            rear = 0;
        else
            rear++;
        array[rear] = o;
    }

    @Override
    public Object removeFirst() {
        if (isEmpty())
            throw new java.util.NoSuchElementException("Queue is Empty");
        if (front == rear) { // One Element in the Queue
            front = -1;
            rear = -1;
        } else {
            if (front == array.length - 1)
                front = 0;
            else {
                array[front] = null;
                front++;
                return array[front];
            }
        }
        return null;
    }

    @Override
    public Object removeLast() {
        if (isEmpty())
            throw new java.util.NoSuchElementException("Queue is Empty");
        if (front == rear)
        {
            front = -1;
            rear = -1;
        }
        else if (rear == 0)
            rear = array.length-1;
        else {
            array[rear] = null;
            rear--;
            return array[rear];
        }
        return null;

    }
    public static <T> ArrayDeque<T> of (T... args) {
        int size = 0;
        for(T o : args)
            size++;
        ArrayDeque<T> temp = new ArrayDeque<>(size);
        for (T o : args) {
            temp.addFirst(o);
        }
        return temp;
    }

    public String toString() {
        return Arrays.toString(array);
    }
    private boolean isFull() {
        return ((front == rear+1    || front == 0 && rear == array.length - 1));
    }
    private boolean isEmpty() {
        return (front == -1);
    }

    public static void main (String[] args) {

        int[] array = new int[]{1,2,3,4};
        System.out.println(Arrays.toString(array));
        ArrayUtils.rotate(array,0);
        System.out.println(Arrays.toString(array));
        ArrayUtils.rotate(array,2);
        System.out.println(Arrays.toString(array));

        char[] charArray = new char[]{'a','b','c','d'};
        System.out.println(Arrays.toString(charArray));
        ArrayUtils.rotate(charArray,1);
        System.out.println(Arrays.toString(charArray));
        ArrayUtils.rotate(charArray,7);
        System.out.println(Arrays.toString(charArray));



    }
}
