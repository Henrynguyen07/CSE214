package applications.arithmetic;

import datastructures.sequential.Stack;

/**
 * @author Henry Nguyen
 * ID: 111484010
 */

public class ToPostfixConverter implements Converter {
    @Override
    /**
     * A "(" is pushed into the operand stack initally. Push operands onto the stack
     * With each token, check if ( is encountered, push onto stack. If operand is encountered, add to postfix expression
     * if ) is encountered, then pop stack until ( is encountered. then discard the ( from the stack. If an operator is encountered
     * repeatedly pop the stack and add each operator to the psotfix expression depending on the presendance. then push the operator
     * onto the stack
     *
     * @param expression Valid arithmic Expression given by user
     * @return result postfix expression
     * @throws Exception When stack is empty or an invalid arithmetic expression
     *
     */
    public String convert(ArithmeticExpression expression) throws Exception {
        String expressedExpression = expression.getExpression();
        // Format Expression
        expressedExpression = expressedExpression.replaceAll("\\[", "(").replaceAll("\\]", ")").replaceAll("\\{", "(").replaceAll("\\}", ")");
        String result = "";
        Stack<Character> stack = new Stack<>();
        stack.push('(');

        int index = 0;
        while (index != expressedExpression.length()) {
            String token = nextToken(expressedExpression, index).trim();
            // Operand
            if (isOperand(token) && !Brackets.isLeftBracket(token) && !Brackets.isRightBracket(token)) {
                result += token + " ";
                index += token.length();
                // If it it a left bracket
            } else if (Brackets.isLeftBracket(token.charAt(0))) {
                stack.push(token.charAt(0));
                index++;
                // If it is a right bracket
            } else if (Brackets.isRightBracket(token)) {
                char temp = stack.pop();
                result += stack.peek();
                if (!stack.isEmpty() && Brackets.isLeftBracket(stack.peek())) {
                    stack.pop();
                    break;
                }
//                if (Brackets.isLeftBracket(temp)) {
//                    result += stack.pop() + " ";
//                } else {
//                    result += temp + " ";
//                }
                index++;
            } else {
                // Operator
                if (!stack.isEmpty()) {
                    if (Operator.of(token).getRank() < Operator.of(stack.peek()).getRank()) {
                        stack.push(token.charAt(0));
                        index++;
                    } else if (Operator.of(token).getRank() == Operator.of(stack.peek()).getRank()) {
                        result += stack.pop() + " ";
                        while (Operator.of(token).getRank() < Operator.of(stack.peek()).getRank()) {
                            stack.push(token.charAt(0));
                            index++;
                        }
                    } else if(Operator.of(token).getRank() > Operator.of(stack.peek()).getRank()) {
                        result += stack.pop() + " ";
                        while (Operator.of(token).getRank() < Operator.of(stack.peek()).getRank()) {
                            stack.push(token.charAt(0));
                            index++;
                        }
                    }
                }
            }
        }

        while (!stack.isEmpty()) {
            char temp = stack.pop();
            if (!Brackets.isLeftBracket(temp) && !Brackets.isRightBracket(temp))
                result += temp + " ";
        }
        return result;
    }

    /**
     * Will be extracting tokens. Operators are its on tokens.
     *
     * @param s     the given string
     * @param start index where to start
     * @return The token at user inputted index
     */
    @Override
    public String nextToken(String s, int start) {
        String tempToken = s + " ";
        String token = "";
        for (int i = start; i < s.length(); i++) {
            if (isOperand(tempToken) && !Operator.isOperator(tempToken.charAt(i + 1)) && !Brackets.isLeftBracket(tempToken.charAt(i + 1)) && !Brackets.isRightBracket(tempToken.charAt(i + 1))) {
                token += tempToken.charAt(i);
            } else if (Operator.isOperator(tempToken) && Operator.isOperator(tempToken)) {
                token += tempToken.charAt(i);
                break;
            } else if (isOperand(tempToken) && !isOperand(String.valueOf(tempToken.charAt(i + 1))) || !Brackets.isLeftBracket(tempToken.charAt(i + 1)) || !Brackets.isRightBracket(tempToken.charAt(i + 1))) {
                token += tempToken.charAt(i);
                break;
            } else if (Operator.isOperator(tempToken) && Operator.isOperator(tempToken.charAt(i + 1))) {
                token += tempToken.charAt(i);
                break;
            } else {
                token += tempToken.charAt(i);
            }
        }
        return token;
    }

    /**
     * If the token is a operand (number) will return true. It will be checking using the wrapper method Operator.isOperator()
     *
     * @param s the given string
     * @return true = is operand, false = not an operand
     */
    @Override
    public boolean isOperand(String s) {
        return !(Operator.isOperator(s));
    }
}
