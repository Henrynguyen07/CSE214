package applications.arithmetic;

public interface Evaluator {
    double evaluate (String expressionString) throws Exception;
}
