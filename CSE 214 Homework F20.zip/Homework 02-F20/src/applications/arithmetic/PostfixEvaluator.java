package applications.arithmetic;

import datastructures.sequential.Stack;

/**
 * @author Henry Nguyen
 * ID: 111484010
 */

public class PostfixEvaluator implements Evaluator {
    Stack<Double> stackDouble = new Stack<Double>();

    @Override
    /**
     * evaluate will take in postfix expression and evaluate returning double type. First will add ")" at the end of the postfix expression.
     * Will break the string into tokens separated by spaces. Each token will be evaluated. If an operand is encountered, push onto the stack.
     * If an operator is encountered, pop the stack of doubles and evaluate val2 of val1
     *
     * @return Postfix Result
     * @throws Exception if stack is empty while popping
     *
     */
    public double evaluate(String expressionString) throws Exception {
        expressionString += ")";
        String temp = "";
        int index = 0;
        double int1 = 0;
        double int2 = 0;

        while (expressionString.charAt(index) != ')' ) {
            // Add Operator to Stack
            if (Operator.isOperator(expressionString.charAt(index))) {
                int1 = stackDouble.pop();
                int2 = stackDouble.pop();
                switch (expressionString.charAt(index)) {
                    case '+':
                        stackDouble.push(int2 + int1);
                        index++;
                        break;
                    case '-':
                        stackDouble.push(int2 - int1);
                        index++;
                        break;
                    case '/':
                        stackDouble.push(int2 / int1);
                        index++;
                        break;
                    case '*':
                        stackDouble.push(int2 * int1);
                        index++;
                        break;
                }
                index++;

                // Encountered Space, Evaluate
            } else if (expressionString.charAt(index) != ' ') {
                while (expressionString.charAt(index) != ' ') {
                    temp += expressionString.charAt(index);
                    index++;
                }
                stackDouble.push(Double.parseDouble(temp));
                temp = "";
                index++;
            }
        }
        return stackDouble.pop();
    }
}

