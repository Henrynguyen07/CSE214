package applications.arithmetic;

/**
 * @author Henry Nguyen
 * ID: 111484010
 */
public class DyckWord {

    private final String word;

    public DyckWord(String word) {
        if (isDyckWord(word))
            this.word = word;
        else
            throw new IllegalArgumentException(String.format("%s is not a valid Dyck word.", word));
    }

     /**
     * Rules of dyck words as follow, the amount of left brackets == the amount of right brackets. In addition, they are nested correctly
     * @param word input from text file
     * @return true = is dyck, false = dyck
     */
    private static boolean isDyckWord(String word) {
        // todo
        boolean dyckFlag = true;
        int parenthesisCount = 0;
        int curlyCount = 0;
        int squareCount = 0;

        for (int i = 0; i < word.length(); i++) {
            if (Brackets.LEFT_PARENTHESIS.getSymbol() == word.charAt(i)) {
                parenthesisCount++;
            } else if (Brackets.LEFT_SQUARE_BRACKET.getSymbol() == word.charAt(i)) {
                squareCount++;
            } else if (Brackets.LEFT_BRACE.getSymbol() == word.charAt(i)) {
                curlyCount++;

            } else {
                if (word.charAt(i) == Brackets.RIGHT_PARENTHESIS.getSymbol()) {
                    parenthesisCount--;
                } else if (word.charAt(i) == Brackets.RIGHT_SQUARE_BRACKET.getSymbol()) {
                    squareCount--;

                } else if (word.charAt(i) == Brackets.RIGHT_BRACE.getSymbol()) {
                    curlyCount--;
                }
            }
            if (parenthesisCount < 0 || curlyCount < 0 || squareCount < 0) {
                dyckFlag = false;
                break;
            }
        }
        return dyckFlag;
    }

    public String getWord() {
        return word;
    }

}
