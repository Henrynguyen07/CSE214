package datastructures.sequential;
/**
 * @author Henry Nguyen
 * ID: 111484010
 */

import java.util.EmptyStackException;

/**
 * Implemented stack by using rules of LinkedList. Lifoqueue is implemented which is an interface. Will provide the necessary methods
 * to implement a stack. Methods include pop, push, peek, and size. Pop will remove the head of the stack, push will add
 * to the stack, peek will return a string value of the head and size will return the length of the stack
 * @param <E> generic stack
 * @throws Exception if stack is empty
 */
public class Stack<E> implements LIFOQueue<E> {
    SNode head;

    /**
     * Constructor
     */
    public Stack() {
        this.head = null;
    }


    /**
     * Returns the head and removes it from the stack
     * @return Removed value of the stack
     * @throws EmptyStackException if Stack is Empty
     */
    @Override
    public E pop() throws EmptyStackException {
        if (head == null) {
            throw new EmptyStackException();
        } else {
            SNode temp = head;
            head = head.getNext();
            return (E) temp.getData();
        }
    }

    /**
     *
     * @param element the element to be pushed onto the top of this stack.
     */
    @Override
    public void push(E element) {
        SNode temp = new SNode(element);
        if (temp == null)
            head = (SNode) element;
        temp.setNext(head);
        head = temp;
    }

    /**
     *
     * @return value of current head
     * @throws EmptyStackException if Stack is Empty
     */
    @Override
    public E peek() throws EmptyStackException {
        if (head == null) {
            throw new EmptyStackException();
        } else
            return (E) head.getData();
    }

    /**
     *
     * @return size of the stack
     * @throws EmptyStackException if stack is empty
     */
    @Override
    public int size() throws EmptyStackException {
        int counter = 0;
        SNode cursor = head;

        if (cursor == null)
            throw new EmptyStackException();
        while (cursor.getNext() != null) {
            cursor = cursor.getNext();
            counter++;
        }
        return counter;
    }

    // False = Filled
    // True = Empty

    /**
     *
     * @return false = filled, true = empty
     */
    @Override
    public boolean isEmpty() {
        return head == null;
    }
}
