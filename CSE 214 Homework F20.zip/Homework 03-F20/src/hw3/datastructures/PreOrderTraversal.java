/**
 * @author Henry Nguyen 111484010
 */

package hw3.datastructures;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ritwik Banerjee
 */
public class PreOrderTraversal<E> extends Traversal<E> {
    List<E> result = new ArrayList<>();

    @Override
    public List<E> of(BinaryTree<E> tree) {
        if (tree.root() != null) {
            preorderTraversal(tree.root());
        }
        return result; // TODO: implement preorder traversal of binary trees
    }

    /**
     * Helper method to do preorder traversal. It will add the node to a list, then traverse left of the tree then right of the tree.
     * @param node
     */
    private void preorderTraversal(BinaryTreeNode node) {
        result.add((E) node.element());
        if (node.left() != null)
            preorderTraversal(node.left());
        if (node.right() != null) {
            preorderTraversal(node.right());

        }
    }

}
