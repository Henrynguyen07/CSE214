/**
 * @author Henry Nguyen 111484010
 */
package hw3.datastructures;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ritwik Banerjee
 */
public class InOrderTraversal<E> extends Traversal<E> {
    List<E> result = new ArrayList<>();

    @Override
    public List<E> of(BinaryTree tree) {
        if (tree.root() != null)
            inorderTraversal(tree.root());
        return result; // TODO: implement inorder traversal of binary trees
    }

    /**
     * Helper method to do inorder traversal. It will traverse left of the tree, then add the node to a list, then traverse right of the tree.
     * @param node
     */
    private void inorderTraversal(BinaryTreeNode node) {
        if (node.left() != null)
            inorderTraversal(node.left());
        result.add((E) node.element());
        if (node.right() != null) {
            inorderTraversal(node.right());

        }
    }
}
