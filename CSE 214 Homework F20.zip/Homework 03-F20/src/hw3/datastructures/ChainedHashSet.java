/**
 * @author Henry Nguyen 111484010
 */
package hw3.datastructures;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
//import java.util.HashSet;

/**
 * This class implements the {@link Set} interface. It offers constant time performance (on average) for the basic
 * operations <code>add</code>, <code>remove</code>, <code>containt</code>, and <code>size</code>, under the simple
 * uniform hashing assumption (i.e., the hash function distributes elements uniformly across the slots in the backing
 * table).
 * There are two constructors given to you. You can modify them, or add new constructors. However, the signature of
 * these two constructors must not be changed. That is, the user must be able to create an instance of this class by
 * invoking <code>new ChainedHashSet()</code> and <code>new ChainedHashSet(int k)</code>.
 *
 * @param <E> the type of elements stored in this set
 */
public class ChainedHashSet<E> implements Set<E> {
    int counter;
    //    ArrayList<LinkedList<E>> table;
    LinkedList[] table;


    /**
     * Once an instance is created, this table size cannot change
     */
    private final int tablesize;

    // DO NOT MODIFY THIS METHOD
    public final int tablesize() {
        return this.tablesize;
    }

    // DO NOT MODIFY THIS METHOD
    public final double loadfactor() {
        return size() / (double) tablesize;
    }

    public ChainedHashSet() {
        this(10);
        int counter = 0;
        table = new LinkedList[tablesize];
        for (int i = 0; i < tablesize(); i++)
            table[i] = new LinkedList();

    }

    public ChainedHashSet(int tablesize) {
        int counter = 0;
        this.tablesize = tablesize;
        table = new LinkedList[tablesize];
        for (int i = 0; i < tablesize(); i++)
            table[i] = new LinkedList();
    }


    @Override
    public int size() {
        return counter; // todo
    }

    @Override
    public boolean isEmpty() {
        return counter == 0; // todo
    }

    @Override

/**
 * Method returns true or false if the node exist within the hashed set.
 */

    public boolean contains(E element) {
        if (element != null) {
            int slot = Math.abs(element.hashCode() % tablesize());
            return table[slot].contains(element);
        }
        throw new NullPointerException("Error: Detected Null");
    }
/**
 * Method returns true or false if the node is able to be added to the hash set. This is implemented using the division method
 */
    @Override
    public boolean add(E e) {
        if (e == null)
            throw new NullPointerException("Error: Detected Null");
        int slot = Math.abs(e.hashCode() % tablesize());
        if (table[slot].contains(e))
            return false;
        else {
            table[slot].add(e);
            counter++;
            return true;
        }

    }

    /**
     *
     * @param e the element to be removed from this set, if present
     * @return true if was able to remove, false if node doesnt exist.
     */

    @Override
    public boolean remove(E e) {
        if (e == null)
            throw new NullPointerException("Error: Detected Null");
        int slot = Math.abs(e.hashCode() % tablesize());
        if (table[slot].contains(e)) {
            table[slot].remove(e);
            counter--;
            return true;
        } else
            return false;
    }

    /**
     * This method returns a string showing the entire hash table structure of this set. The format must be as follows:
     * Suppose a table has four slots, with three elements 'a', 'b', 'c', hashed to the first slot and 'z' hashed to the
     * third slot. Printing out the returned string should show the following:
     * <p>
     * 1 || a -> b -> c
     * 2 ||
     * 3 || z
     * <p>
     * Note that the elements 'a', 'b', 'c', and 'z' must also be human-readable.
     *
     * @return a string representation of the entire set, showing the underlying hash table structure
     */
    @Override
    public String toString() {
        String result = "";
        for (int i = 0; i < table.length; i++) {
            result += i + 1 + " || ";
            for (int j = 0; j < table[i].size() - 1; j++)
                result += table[i].get(j).toString() + " -> ";
            if (table[i].size() != 0)
                result += table[i].get(table[i].size() - 1).toString();
            result += "\n";
        }
        return result; // todo
    }
}
