/**
 * @author Henry Nguyen 111484010
 */
package hw3.datastructures;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ritwik Banerjee
 */
public class PostOrderTraversal<E> extends Traversal<E> {
    List<E> result = new ArrayList<>();

    @Override
    public List<E> of(BinaryTree tree) {
        if (tree.root() != null)
            postorderTraversal(tree.root());
        return result; // TODO: implement postorder traversal of binary trees
    }

    /**
     * Helper method used to do postorder traversal. It will traverse left of the tree, then right then add the node to a list.
     * @param node
     */
    private void postorderTraversal(BinaryTreeNode<E> node) {
        if (node.left() != null)
            postorderTraversal(node.left());
        if (node.right() != null)
            postorderTraversal(node.right());
        result.add((E) node.element());

    }
}
